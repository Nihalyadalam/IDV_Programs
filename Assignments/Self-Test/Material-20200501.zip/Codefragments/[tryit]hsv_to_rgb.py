hsv_value = (180, 0.5, 1)
print ("hsv: ", hsv_value)
rgb_value =                     #add your code here
print ("rgb: ", rgb_value)
rgb_value_255 =                  #add your code here
print("rgb: ", rgb_value_255)