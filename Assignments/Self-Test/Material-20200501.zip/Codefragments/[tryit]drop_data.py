arr = "Hello World!"
cut1 = 6
cut2 = 12
subarr1 = arr[:cut1]
subarr2 = arr[cut1:cut2]
subarr3 = arr[cut2:]

print(subarr1, subarr2, subarr3)

name =                     #add your name as string here
print(subarr1, name, arr[len(arr)-1])